class customApiError extends Error{
  constructor(message){
  super(message)
  }
}
export default customApiError;