import BadRequestError from "./BadRequestError.js";
import notFoundError from "./notFoundError.js";
export default {BadRequestError,notFoundError}