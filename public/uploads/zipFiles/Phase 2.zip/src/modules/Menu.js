import { Popover, MenuItem } from "@mui/material";

export default function Menu(props) {
  const { anchorEl, open, onClose, openDialog } = props;
  return (
    <Popover
      anchorEl={anchorEl}
      open={open}
      onClose={onClose}
      anchorOrigin={{
        vertical: "bottom",
        horizontal: "center",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "center",
      }}
      keepMounted
      transitionDuration={0}
    >
      <MenuItem onClick={openDialog}>Update profil</MenuItem>
      <MenuItem onClick={onClose}>Logout</MenuItem>
    </Popover>
  );
}
