import {
  Box,
  Drawer,
  ListItem,
  Typography,
  Button,
  Avatar,
  styled,
  IconButton,
} from "@mui/material";
import logo from "../assets/images/logo.svg";
import dashboard from "../assets/images/menu/dashboard.svg";
import allUsers from "../assets/images/menu/all-users.svg";
import gallery from "../assets/images/menu/gallery.svg";
import receipt from "../assets/images/menu/receipt.svg";
import arrow from "../assets/images/arrow.svg";
import bell from "../assets/images/bell.svg";
import { Link, useLocation } from "react-router-dom";
import Menu from "./Menu";
import { useRef, useState } from "react";
import EditUserDialog from "./EditUserDialog";
import AreYouSureDialog from "./components/AreYouSureDialog";

const Container = styled("div")(({ theme }) => ({
  display: "flex",
  flex: "1 1 auto",
  maxWidth: "100%",
  [theme.breakpoints.up("lg")]: {
    paddingLeft: 280,
  },
}));

export default function ContentWrapper({ children }) {
  const currentPath = useLocation();
  const [open, setIsOpen] = useState(false);
  const [openDialog, setOpenDialog] = useState(false);
  const [submitDialog, setSubmitDialog] = useState(false);
  const ref = useRef(null);

  const handleOpenDialog = () => {
    setIsOpen(false);
    setOpenDialog(true);
  };

  const menu = [
    {
      label: "Dashboard",
      icon: dashboard,
      path: "/dashboard",
    },
    {
      label: "All Users",
      icon: allUsers,
      path: "/all-users",
    },
    {
      label: "Users",
      icon: gallery,
      path: "/users",
    },
    {
      label: "Team Members",
      icon: receipt,
      path: "/team-members",
    },
    {
      label: "Plan Library",
      icon: gallery,
      path: "/plan-library",
    },
    {
      label: "Design Library",
      icon: receipt,
      path: "/design-library",
    },
    {
      label: "All Tasks",
      icon: receipt,
      path: "/all-tasks",
    },
    {
      label: "Report",
      icon: receipt,
      path: "/reports",
    },
  ];

  console.log("op", submitDialog);

  return (
    <Box>
      <Box sx={{ display: "flex" }}>
        <Drawer
          anchor="left"
          open
          variant="permanent"
          PaperProps={{
            sx: {
              width: 280,
              borderRightColor: "divider",
              borderRightStyle: "solid",
              background: "#F2F2F2",
            },
          }}
        >
          <Box
            sx={{
              mt: 5,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
            }}
          >
            <img src={logo} alt="logo" style={{ marginBottom: "64px" }} />
            {menu.map((item, index) => {
              const getCurrentPath =
                item.path === currentPath.pathname ? true : false;
              return (
                <ListItem
                  key={index}
                  sx={{
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                  }}
                >
                  <Link
                    to={item.path}
                    style={{ maxWidth: "190px", width: "100%" }}
                  >
                    <Button
                      disableRipple
                      startIcon={
                        <img
                          src={item.icon}
                          style={{ color: "red" }}
                          alt="dashboard"
                        />
                      }
                      sx={{
                        textAlign: "left",
                        justifyContent: "flex-start",
                        textTransform: "none",
                        textDecoration: "none",
                        width: "100%",
                        py: 1,
                        pl: 2,
                        background: getCurrentPath
                          ? "linear-gradient(99.32deg, #B4CD93 7.91%, #427A5B 88.96%)"
                          : "#F2F2F2",
                        color: getCurrentPath ? "#fff" : "#808080",
                        marginBottom: 2,
                      }}
                    >
                      <Typography
                        sx={{
                          fontWeight: 500,
                          fontSize: 16,
                          lineHeight: 1.5,
                          ml: 0.5,
                        }}
                      >
                        {item.label}
                      </Typography>
                    </Button>
                  </Link>
                </ListItem>
              );
            })}
          </Box>
        </Drawer>
        <Box
          sx={{
            pl: "344px",
            pr: "66px",
            flex: 1,
            height: "104px",
            background: "#F2F2F2",
            pt: 2,
            display: "flex",
            alignItems: "start",
            justifyContent: "space-between",
          }}
        >
          <Box>
            <Box sx={{ display: "flex", alignItems: "center" }}>
              <img src={arrow} alt="arrow" />
              <Typography sx={{ ml: 1, fontSize: "32px", fontWeight: 500 }}>
                Dashboard
              </Typography>
            </Box>
            <Typography
              sx={{
                color: "#B8B8B8",
                fontWeight: 400,
                fontSize: "12px",
                ml: 2.2,
              }}
            >
              Welcome back, Leo
            </Typography>
          </Box>
          <Box sx={{ display: "flex", alignItems: "center", pt: 1 }}>
            <IconButton>
              <img src={bell} alt="bell" />
            </IconButton>
            <Avatar sx={{ width: "32px", height: "32px", mr: 1, ml: 0.88 }} />
            <Box
              sx={{ cursor: "pointer" }}
              ref={ref}
              onClick={() => setIsOpen(true)}
            >
              <Typography
                sx={{
                  textTransform: "uppercase",
                  fontWeight: 600,
                  fontSize: "16px",
                }}
              >
                Leonardo Lavi
              </Typography>
              <Typography
                sx={{ color: "#B8B8B8", fontWeight: 400, fontSize: "12px" }}
              >
                Leonardo1@gmail.com
              </Typography>
            </Box>
          </Box>
        </Box>
        <Menu
          onClose={() => setIsOpen(false)}
          openDialog={handleOpenDialog}
          open={open}
          anchorEl={ref.current}
        />
        <EditUserDialog
          openSubmit={() => setSubmitDialog(true)}
          open={openDialog}
          onClose={() => setOpenDialog(false)}
        />
        <AreYouSureDialog
          open={submitDialog}
          onClose={() => setSubmitDialog(false)}
          title="Are you sure you want to  Update the Profile ?"
          submitText="Yes, Update"
        />
      </Box>
      <Container>
        <Box
          sx={{
            display: "flex",
            flex: "1 1 auto",
            flexDirection: "column",
            width: "100%",
          }}
        >
          {children}
        </Box>
      </Container>
    </Box>
  );
}
