import { Container, Box } from "@mui/system";

export default function ViewContainer({ sx, containerProp, children }) {
  return (
    <Box
      sx={{
        ...sx,
        flexGrow: 1,
        py: 4,
        px: 4.6,
      }}
    >
      <Container {...containerProp} maxWidth="xl">
        {children}
      </Container>
    </Box>
  );
}
