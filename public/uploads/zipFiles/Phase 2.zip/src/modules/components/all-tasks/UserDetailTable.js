import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Box,
  TextField,
  Typography,
  IconButton,
} from "@mui/material";
import Pagination from "../../Pagination";
import trashIcon from "../../../assets/images/trash.svg";
import editIcon from "../../../assets/images/edite.svg";
import userIconTable from "../../../assets/images/users/user1.png";

export default function UserDetailTable() {
  const tableColumns = [
    <TableCell key="id">Post ID</TableCell>,
    <TableCell key="text">Text on post</TableCell>,
    <TableCell key="sesign">Design</TableCell>,
  ];

  const data = [
    {
      id: "1434",
      userImg: userIconTable,
    },
    {
      id: "1434",
      userImg: userIconTable,
    },
    {
      id: "1434",
      userImg: userIconTable,
    },
    {
      id: "1434",
      userImg: userIconTable,
    },
    {
      id: "1434",
      userImg: userIconTable,
    },
  ];
  return (
    <Table
      sx={{
        background: "transparent",
        border: "none",
        mb: 2,
        "& td": {
          border: 0,
          justifyContent: "center",
          textAlign: "center",
          height: "96px",
          borderBottom: "1px solid #ccc",
          py: 1,
        },
        "& th": {
          paddingTop: 4,
          border: 0,
          textAlign: "center",
        },
      }}
    >
      <TableHead>
        <TableRow>{tableColumns}</TableRow>
      </TableHead>
      <TableBody>
        {data.map((item, index) => (
          <RowItem key={index} item={item} />
        ))}
      </TableBody>
    </Table>
  );
}

function RowItem(props) {
  const { item } = props;
  return (
    <TableRow>
      <TableCell>
        <Typography
          sx={{ color: "#808080", fontWeight: 500, fontSize: "16px" }}
        >
          {item.id}
        </Typography>
      </TableCell>
      <TableCell>
        <TextField
          sx={{
            borderRadius: 2,
            background: "#fff",
            "& .MuiOutlinedInput-notchedOutline": {
              border: "none",
            },
            "& .MuiFormControl-root": {
              height: "48px",
            },
            "& .MuiInputBase-root": {
              height: "48px",
              fontSize: "10px",
              py: 3.7,
            },
          }}
          placeholder="Write you description here"
          fullWidth
          rows={3.5}
          multiline
          name={item.description}
        />
      </TableCell>
      <TableCell>
        <Box display="flex" alignItem="center" justifyContent="center">
          <img
            src={item.userImg}
            style={{ width: "32px", height: "32px" }}
            alt={item.id}
          />
          <IconButton sx={{ ml: 2 }}>
            <img src={trashIcon} alt="trash" />
          </IconButton>
          <IconButton>
            <img src={editIcon} alt="edite" />
          </IconButton>
        </Box>
      </TableCell>
    </TableRow>
  );
}
