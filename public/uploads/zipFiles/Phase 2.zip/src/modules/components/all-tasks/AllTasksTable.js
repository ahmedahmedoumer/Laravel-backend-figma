import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Box,
  Card,
} from "@mui/material";
import user1 from "../../../assets/images/users/user1.png";
import user2 from "../../../assets/images/users/user2.png";
import user3 from "../../../assets/images/users/user3.png";
import user4 from "../../../assets/images/users/user4.png";
import user5 from "../../../assets/images/users/user5.png";
import user6 from "../../../assets/images/users/user6.png";
import Pagination from "../../Pagination";
import view from "../../../assets/images/view.svg";

export default function AllTasksTable() {
  const tableColumns = [
    <TableCell key="name">User Name</TableCell>,
    <TableCell key="industry">Industry</TableCell>,
    <TableCell key="status">Status</TableCell>,
    <TableCell key="recievedTime">Recieved Time</TableCell>,
    <TableCell key="submitDate">Submit date</TableCell>,
    <TableCell key="view">View</TableCell>,
  ];

  const data = [
    {
      img: user1,
      name: "Omar",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "new",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
    {
      img: user2,
      name: "Ahmed",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "approved",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
    {
      img: user3,
      name: "Leo",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "needEdit",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
    {
      img: user4,
      name: "Cris",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "pending",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
    {
      img: user5,
      name: "Matheo",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "new",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
    {
      img: user6,
      name: "Sergio",
      industry: "Real Estet",
      recievedTime: ["22/04/2023", "7:00 Am"],
      status: "approved",
      submitDate: ["22/04/2023", "7:00 Am"],
    },
  ];

  return (
    <Card
      sx={{
        background: "#F2F2F2",
        borderRadius: "30px",
        p: 0,
        mt: 3,
        mb: 6,
        boxShadow: "none",
      }}
    >
      <Table
        sx={{
          background: "transparent",
          border: "none",
          mb: 2,
          "& td": {
            justifyContent: "center",
            textAlign: "center",
            py: 1.5,
            boderBottom: "1px solid #ccc",
          },
          "& th": {
            paddingTop: 4,
            border: 0,
            textAlign: "center",
          },
        }}
      >
        <TableHead>
          <TableRow>{tableColumns}</TableRow>
        </TableHead>
        <TableBody>
          {data.map((item, index) => (
            <RowItem key={index} item={item} />
          ))}
        </TableBody>
      </Table>
      <Box sx={{ ml: 4, mb: 4 }}>
        <Pagination />
      </Box>
    </Card>
  );
}

function RowItem(props) {
  const { item } = props;
  return (
    <TableRow>
      <TableCell>
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            mx: "auto",
            maxWidth: 120,
            width: "100%",
          }}
        >
          <img src={item.img} alt={item.name} />
          <Typography
            sx={{ ml: 2, fontSize: "16px", fontWeight: 500, color: "#808080" }}
          >
            {item.name}
          </Typography>
        </Box>
      </TableCell>
      <TableCell>
        <Typography
          sx={{
            ml: 1,
            color: "#7F7F7F",
            fontSize: "14px",
            fontWeight: 500,
          }}
        >
          {item.industry}
        </Typography>
      </TableCell>
      <TableCell>
        <Box
          sx={{
            background: STATUS_BG_COLOR[item.status],
            color: STATUS_COLOR[item.status],
            width: "92px",
            margin: "0 auto",
            fontWeight: 300,
            fontSize: "12px",
            borderRadius: "5px",
          }}
        >
          <Typography>{STATUS_MESSAGE[item.status]}</Typography>
        </Box>
      </TableCell>
      <TableCell>
        {item.recievedTime.map((time) => (
          <Typography>{time}</Typography>
        ))}
      </TableCell>
      <TableCell>
        {item.submitDate.map((date) => (
          <Typography>{date}</Typography>
        ))}
      </TableCell>
      <TableCell>
        <Box>
          <img src={view} alt="view" />
        </Box>
      </TableCell>
    </TableRow>
  );
}

const STATUS_COLOR = {
  new: "#8D1C04",
  approved: "#427A5B",
  notYet: "#161211",
  pending: "#692600",
  needEdit: "#161211",
};

const STATUS_BG_COLOR = {
  new: "#FFBBB7",
  approved: "#DEEDE5",
  notYet: "#D1D1D1",
  pending: "#FFC19E",
  needEdit: "#FDF8CE",
};

const STATUS_MESSAGE = {
  new: "New",
  approved: "Approved",
  notYet: "Not Yet",
  pending: "Pending",
  needEdit: "Need Edit",
};
