import {
  Box,
  Button,
  Card,
  Grid,
  InputLabel,
  TextField,
  Typography,
  InputAdornment,
} from "@mui/material";
import { POPPINS } from "../../../utils/config";
import userIcon from "../../../assets/images/user-detail.svg";
import fileIcon from "../../../assets/images/file.svg";
import search from "../../../assets/images/search.svg";
import plusIcon from "../../../assets/images/plus.svg";
import doneIcon from "../../../assets/images/done.svg";
import filesIcon from "../../../assets/images/files.svg";
import redPluse from "../../../assets/images/plusRed.svg";
import UserDetailTable from "./UserDetailTable";
import Pagination from "../../Pagination";

export default function UserDetiail() {
  return (
    <>
      <Card
        sx={{
          background: "#F2F2F2",
          borderRadius: "20px",
          boxShadow: "none",
          pl: 4,
          py: 1.5,
        }}
      >
        <Grid container alignItems="center" spacing={3}>
          <Grid item lg={1}>
            <img src={userIcon} alt="user" />
          </Grid>
          <Grid
            item
            lg={3}
            sx={{
              "& .MuiFormControl-root": {
                height: "26px",
              },
              "& .MuiInputBase-root": {
                height: "26px",
                fontSize: "10px",
                py: 1.7,
              },
            }}
          >
            <Grid>
              <InputLabel sx={{ ...labelStyle }} htmlFor="co-name">
                CO. Name
              </InputLabel>
              <TextField
                fullWidth
                size="small"
                name="coName"
                id="co-name"
                sx={{ background: "#fff" }}
                placeholder="Company Name"
              />
            </Grid>
            <Grid sx={{ mt: 1 }}>
              <InputLabel sx={{ ...labelStyle }} htmlFor="co-industry">
                CO. Industry
              </InputLabel>
              <TextField
                fullWidth
                size="small"
                name="coIndustry"
                id="co-industry"
                sx={{ background: "#fff" }}
                placeholder="Company Industry"
              />
            </Grid>
          </Grid>
          <Grid
            item
            lg={3}
            sx={{
              "& .MuiFormControl-root": {
                height: "26px",
              },
              "& .MuiInputBase-root": {
                height: "26px",
                fontSize: "10px",
                py: 1.7,
              },
            }}
          >
            <Grid>
              <InputLabel sx={{ ...labelStyle }} htmlFor="co-name">
                CO. Name
              </InputLabel>
              <TextField
                fullWidth
                size="small"
                name="coName"
                id="co-name"
                sx={{ background: "#fff" }}
                placeholder="Company Name"
              />
            </Grid>
            <Grid sx={{ mt: 1 }}>
              <InputLabel sx={{ ...labelStyle }} htmlFor="co-industry">
                CO. Industry
              </InputLabel>
              <TextField
                fullWidth
                size="small"
                name="coIndustry"
                id="co-industry"
                sx={{ background: "#fff" }}
                placeholder="Company Industry"
              />
            </Grid>
          </Grid>
          <Grid
            item
            lg={3}
            sx={{
              "& .MuiInputBase-root": {
                fontSize: "10px",
              },
            }}
          >
            <InputLabel sx={{ ...labelStyle }} htmlFor="content-description">
              Content description
            </InputLabel>
            <TextField
              fullWidth
              multiline
              rows={5}
              size="small"
              sx={{ background: "#fff" }}
              name="contentDescription"
              id="content-description"
              placeholder="Write you company description here "
            />
          </Grid>
          <Grid item lg={1}>
            <Button
              sx={{
                height: "88px",
                mt: 2.9,
                px: 2,
                textTransform: "unset",
                color: "#565656",
                background: "#fff",
                border: "1px solid #E8E8E8",
                borderRadius: "6px",
              }}
              startIcon={<img src={fileIcon} alt="img" />}
            >
              Assets
            </Button>
          </Grid>
        </Grid>
      </Card>
      <Box
        sx={{
          display: "flex",
          alignItem: "center",
          justifyContent: "space-between",
          mt: 3,
        }}
      >
        <Typography sx={{ fontWeight: 500, fontSize: "24px", ...POPPINS }}>
          Total Users : 150
        </Typography>
        <Box display="flex">
          <Box>
            <TextField
              sx={{
                border: "1px solid #7F7F7F",
                borderRadius: 2,
                background: "#F2F2F2",
                maxWidth: "290px",
                width: "100%",
                "& .MuiOutlinedInput-notchedOutline": {
                  border: "none",
                },
              }}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <img src={search} alt="search" />
                  </InputAdornment>
                ),
              }}
              size="small"
              name="search"
              placeholder="Search"
              //   value={serchValue}
              //   onChange={(e) => onSearch(e.target.value)}
            />
          </Box>
          <Box>
            <Button
              startIcon={<img src={plusIcon} alt="plus" />}
              sx={{
                color: "white",
                background:
                  "linear-gradient(99.32deg, #B4CD93 7.91%, #427A5B 88.96%)",
                border: "0.5px solid #7F7F7F",
                borderRadius: "8px",
                textTransform: "unset",
                pl: 4,
                pr: 2,
                ml: 1,
                py: 0.88,
              }}
            >
              Add Row
            </Button>
          </Box>
          <Box>
            <Button
              startIcon={<img src={plusIcon} alt="plus" />}
              sx={{
                color: "white",
                background:
                  "linear-gradient(99.32deg, #B4CD93 7.91%, #427A5B 88.96%)",
                border: "1px solid #7F7F7F",
                borderRadius: "8px",
                textTransform: "unset",
                pl: 4,
                pr: 2,
                ml: 1,
                py: 0.88,
              }}
            >
              Add Bulk Plan
            </Button>
          </Box>
          <Box>
            <Button
              startIcon={
                <img src={redPluse} alt="plus" style={{ marginTop: "2.4px" }} />
              }
              sx={{
                color: "#978F8F",
                border: "1px solid #D40101",
                background: "#F2F2F2",
                borderRadius: "8px",
                textTransform: "unset",
                pr: 2,
                ml: 1,
                py: 0.88,
              }}
            >
              More Edit
            </Button>
          </Box>
          <Box>
            <Button
              startIcon={<img src={filesIcon} alt="plus" />}
              sx={{
                color: "#978F8F",
                border: "1px solid #B4CD93",
                background: "#F2F2F2",
                borderRadius: "8px",
                textTransform: "unset",
                pr: 2,
                ml: 1,
                py: 0.88,
              }}
            >
              Save
            </Button>
          </Box>
          <Box>
            <Button
              startIcon={<img src={doneIcon} alt="plus" />}
              sx={{
                color: "#978F8F",
                border: "0.5px solid #B4CD93",
                background: "#F2F2F2",
                borderRadius: "8px",
                textTransform: "unset",
                pr: 2,
                ml: 1,
                py: 0.88,
              }}
            >
              Approve
            </Button>
          </Box>
        </Box>
      </Box>
      <Card
        sx={{
          background: "#F2F2F2",
          borderRadius: "30px",
          p: 0,
          mt: 3,
          mb: 6,
          boxShadow: "none",
        }}
      >
        <Box sx={{ display: "flex" }}>
          <UserDetailTable />
          <UserDetailTable />
        </Box>
        <Box sx={{ ml: 4, mb: 4 }}>
          <Pagination />
        </Box>
      </Card>
    </>
  );
}

const labelStyle = {
  ...POPPINS,
  mb: 1,
  color: "#565656",
  fontWeight: 500,
  fontSize: "14px",
};
