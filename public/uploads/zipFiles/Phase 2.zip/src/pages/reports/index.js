import { Box } from "@mui/material";
import ReportsTable from "../../modules/components/reports/ReportsTable";
import PageHeader from "../../modules/PageHeader";
import ViewContainer from "../../modules/ViewContainer";
import ViewDate from "../../modules/ViewDate";

export default function Reports() {
  return (
    <ViewContainer>
      <PageHeader
        title="Reports"
        description="Lookup for All the Design Library"
      />
      <ReportsTable />
      <Box sx={{ display: "flex", justifyContent: "center" }}>
        <ViewDate />
      </Box>
    </ViewContainer>
  );
}
