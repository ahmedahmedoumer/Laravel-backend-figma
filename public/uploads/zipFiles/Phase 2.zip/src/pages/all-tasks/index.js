import { Box } from "@mui/material";
import AllTasksTable from "../../modules/components/all-tasks/AllTasksTable";
import UserDetiail from "../../modules/components/all-tasks/UserDetiail";
import PageHeader from "../../modules/PageHeader";
import ViewContainer from "../../modules/ViewContainer";
import ViewDate from "../../modules/ViewDate";

export default function AllTasks() {
  return (
    <ViewContainer>
      <PageHeader
        title="All Tasks"
        description="Lookup for All the All tasks"
      />
      <AllTasksTable />
      {/* <UserDetiail /> */}
      <Box sx={{ display: "flex", justifyContent: "center" }}>
        <ViewDate />
      </Box>
    </ViewContainer>
  );
}
