export const POPPINS = {
  fontFamily: "Poppins !important",
};
